﻿namespace TeisterMask.DataProcessor.ImportDto
{
    public class TaskInputModelJson
    {
        public int Id { get; set; }
    }
}
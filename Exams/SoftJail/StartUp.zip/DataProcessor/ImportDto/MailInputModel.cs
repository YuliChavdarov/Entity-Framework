﻿namespace SoftJail.DataProcessor.ImportDto
{
    public class MailInputModel
    {
        public string Description { get; set; }
        public string Sender { get; set; }
        public string Address { get; set; }
    }

}

﻿namespace SoftJail.DataProcessor.ImportDto
{
    public class CellInputModel
    {
        public int CellNumber { get; set; }
        public bool HasWindow { get; set; }
    }
}